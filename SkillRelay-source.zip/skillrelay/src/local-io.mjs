import { constants } from "node:fs";
import { open } from "node:fs/promises";

export async function readBoundedFile(path, max, { noLinks = false } = {}) {
  const flags = constants.O_RDONLY | (noLinks ? constants.O_NOFOLLOW ?? 0 : 0);
  const file = await open(path, flags);
  try {
    const stat = await file.stat();
    if (!stat.isFile()) throw new Error("Choose a regular file.");
    if (stat.size > max) throw new Error("The input file exceeds SkillRelay’s size limit.");
    const bytes = Buffer.alloc(stat.size + 1);
    let offset = 0;
    while (offset < bytes.length) {
      const { bytesRead } = await file.read(bytes, offset, bytes.length - offset, offset);
      if (!bytesRead) return bytes.subarray(0, offset);
      offset += bytesRead;
    }
    throw new Error("The file changed while SkillRelay read it. Try again.");
  } finally {
    await file.close();
  }
}
