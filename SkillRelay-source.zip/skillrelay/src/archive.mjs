import { Uint8ArrayReader, Uint8ArrayWriter, ZipReader, ZipWriter } from "@zip.js/zip.js";

const mib = 1024 * 1024;
export const limits = Object.freeze({
  zip: 24 * mib,
  unpacked: 20 * mib,
  entry: 10 * mib,
  entries: 256,
  markdown: 512 * 1024,
});

const windowsDevice = /^(con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])(?:\.|$)/i;

function pathParts(path) {
  const parts = path.split("/");
  if (path.length > 240 || parts.some(part =>
    !part || part === "." || part === ".." ||
    /[\\:*?"<>|\u0000-\u001f\u007f]/u.test(part) ||
    /[. ]$/u.test(part) || windowsDevice.test(part)
  )) {
    throw new Error("The archive contains a path that cannot be used safely on all platforms.");
  }
  return parts;
}

function recordPath(index, path, isDirectory) {
  const parts = pathParts(path);
  let prefix = "";
  for (const [i, part] of parts.entries()) {
    prefix = prefix ? `${prefix}/${part}` : part;
    const key = prefix.normalize("NFC").toLowerCase();
    const directory = isDirectory || i < parts.length - 1;
    const previous = index.get(key);
    if (previous && (prefix !== previous.path || !directory || !previous.directory)) {
      throw new Error("The archive contains duplicate or conflicting paths.");
    }
    index.set(key, { path: prefix, directory });
  }
}

function enforceSize(size, max, label) {
  if (!Number.isSafeInteger(size) || size < 0 || size > max) {
    throw new Error(`${label} exceeds SkillRelay’s size limit.`);
  }
}

async function readEntry(entry) {
  const bytes = new Uint8Array(entry.uncompressedSize);
  let offset = 0;
  const sink = new WritableStream({
    write(chunk) {
      if (offset + chunk.length > bytes.length) {
        throw new Error("A ZIP entry expanded beyond its declared size.");
      }
      bytes.set(chunk, offset);
      offset += chunk.length;
    },
  });
  await entry.getData(sink, { checkCrc32: true, checkOverlappingEntry: true });
  if (offset !== bytes.length) throw new Error("A ZIP entry did not match its declared size.");
  return bytes;
}

export async function readZip(bytes) {
  enforceSize(bytes.length, limits.zip, "The ZIP file");
  const reader = new ZipReader(new Uint8ArrayReader(bytes), {
    strictness: "strict",
    useWebWorkers: false,
  });
  try {
    const index = new Map();
    const entries = [];
    const explicitPaths = new Set();
    let unpacked = 0;
    let count = 0;
    for await (const entry of reader.getEntriesGenerator()) {
      if (++count > limits.entries) throw new Error("The ZIP contains too many entries (maximum 256).");
      const path = entry.directory ? entry.filename.replace(/\/$/, "") : entry.filename;
      if (explicitPaths.has(path)) throw new Error("The ZIP contains a duplicate entry.");
      explicitPaths.add(path);
      recordPath(index, path, entry.directory);
      const fileType = ((entry.unixMode ?? (entry.externalFileAttributes >>> 16)) & 0o170000);
      if (entry.symlink || (fileType && ![0o100000, 0o040000].includes(fileType))) {
        throw new Error("The ZIP contains a symbolic link or special file.");
      }
      if (entry.encrypted) throw new Error("Password-protected ZIP files are unsupported.");
      if (entry.directory) continue;
      enforceSize(entry.uncompressedSize, limits.entry, "A ZIP entry");
      unpacked += entry.uncompressedSize;
      enforceSize(unpacked, limits.unpacked, "The unpacked ZIP");
      entries.push([path, entry]);
    }
    const files = new Map();
    for (const [path, entry] of entries) {
      files.set(path, await readEntry(entry));
    }
    return files;
  } catch (error) {
    throw new Error(`Could not read ZIP: ${error.message}`, { cause: error });
  } finally {
    await reader.close();
  }
}

export async function writeZip(files) {
  if (files.size > limits.entries) throw new Error("Too many files to package.");
  const writer = new ZipWriter(new Uint8ArrayWriter(), {
    useWebWorkers: false,
    level: 6,
    extendedTimestamp: false,
    lastModDate: new Date(2000, 0, 1),
  });
  const index = new Map();
  const paths = [...files.keys()].sort();
  let unpacked = 0;
  for (const path of paths) {
    recordPath(index, path, false);
    const size = files.get(path).length;
    enforceSize(size, limits.entry, "An output entry");
    unpacked += size;
    enforceSize(unpacked, limits.unpacked, "The unpacked output");
  }
  for (const path of paths) {
    await writer.add(path, new Uint8ArrayReader(files.get(path)));
  }
  const result = await writer.close();
  enforceSize(result.length, limits.zip, "The output ZIP");
  return result;
}
