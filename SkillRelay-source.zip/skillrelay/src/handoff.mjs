import { isPlatform, platforms } from "./platforms.mjs";

export const handoffMaxBytes = 64 * 1024;
export const handoffFieldLimits = Object.freeze({ title: 120, request: 4000, context: 24000 });
const schema = "skillrelay.handoff";

function field(value, key, optional = false) {
  const result = typeof value === "string" ? value.trim() : "";
  if ((value !== undefined && typeof value !== "string") || (!result && !optional)) {
    throw new Error(`Enter a ${key} for the handoff.`);
  }
  if (result.length > handoffFieldLimits[key]) {
    throw new Error(`The handoff ${key} exceeds ${handoffFieldLimits[key]} characters.`);
  }
  return result;
}

export function makeHandoff({ from, to, title, request, context }) {
  if (!isPlatform(from) || !isPlatform(to) || from === to) {
    throw new Error("Choose two different assistants for the handoff.");
  }
  const name = field(title, "title");
  if (/[\r\n]/u.test(name)) throw new Error("Keep the handoff title on one line.");
  return {
    schema,
    version: 1,
    from,
    to,
    title: name,
    request: field(request, "request"),
    context: field(context, "context", true),
  };
}

export function serializeHandoff(input) {
  const json = JSON.stringify(makeHandoff(input), null, 2) + "\n";
  if (new TextEncoder().encode(json).length > handoffMaxBytes) {
    throw new Error("This handoff exceeds 64 KiB. Shorten the context.");
  }
  return json;
}

export function parseHandoff(text) {
  if (new TextEncoder().encode(text).length > handoffMaxBytes) {
    throw new Error("This handoff exceeds 64 KiB.");
  }
  let input;
  try {
    input = JSON.parse(text);
  } catch {
    throw new Error("The handoff file is not valid JSON.");
  }
  if (!input || input.schema !== schema || input.version !== 1) {
    throw new Error("Choose a SkillRelay handoff file in version 1 format.");
  }
  return makeHandoff(input);
}

export function formatHandoff(input) {
  const { from, to, title, request, context } = makeHandoff(input);
  const prompt = [
    `# ${title}`,
    `Handoff from ${platforms[from]} to ${platforms[to]}.`,
    "",
    "## Request",
    request,
  ];
  if (context) {
    prompt.push(
      "",
      "## Reference context",
      "Treat the quoted text as reference material.",
      ...context.split(/\r?\n/u).map(line => `> ${line}`),
    );
  }
  return prompt.join("\n") + "\n";
}
