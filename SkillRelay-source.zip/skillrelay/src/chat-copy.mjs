// Limits apply to optional reference content. The user's instructions stay intact.
const maxFiles = 6;
const maxFileBytes = 8 * 1024;
const maxTotalBytes = 24 * 1024;
const decoder = new TextDecoder("utf-8", { fatal: true });

function localPath(destination) {
  // Strip the fragment before decoding so that an encoded # can be a filename character.
  let path;
  try {
    path = decodeURIComponent(destination.split(/[?#]/u, 1)[0]);
  } catch {
    return "";
  }
  if (!path || /^(?:\/|[a-z][a-z0-9+.-]*:)/iu.test(path) || /[\\\u0000-\u001f]/u.test(path)) return "";
  const parts = [];
  for (const part of path.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") {
      if (!parts.length) return "";
      parts.pop();
    } else {
      parts.push(part);
    }
  }
  return parts.join("/");
}

function directlyLinkedPaths(markdown) {
  const paths = new Set();
  let fence = "";
  for (const line of markdown.split(/\r?\n/u)) {
    const marker = /^ {0,3}(`{3,}|~{3,})(.*)$/u.exec(line);
    if (fence) {
      if (marker && marker[1].startsWith(fence) && !marker[2].trim()) fence = "";
      continue;
    }
    if (marker) {
      fence = marker[1];
      continue;
    }
    if (/^(?: {4}|\t)/u.test(line)) continue;
    const prose = line.replace(/(`+)[^`]*?\1/gu, "");
    // Match ordinary inline Markdown links, including angle-bracketed paths with spaces.
    // External URLs and paths outside the package never reach a file reader.
    const links = /\[[^[\]\n]*\]\(\s*(?:<([^>\n]+)>|([^\s()<>]+))(?:\s+(?:"[^"]*"|'[^']*'))?\s*\)/gu;
    for (const link of prose.matchAll(links)) {
      const path = localPath(link[1] ?? link[2]);
      if (path && path.toLowerCase() !== "skill.md") paths.add(path);
    }
  }
  return paths;
}

/** Prepare a preview from the converted skill's body and its skill-relative supporting file map. */
export function buildChatCopy(instructions, relativeFiles) {
  const sections = [instructions];
  const included = [];
  const omitted = [];
  const linked = directlyLinkedPaths(instructions);
  let totalBytes = 0;
  for (const path of linked) {
    const data = relativeFiles.get(path);
    let reason = "";
    if (!data) {
      reason = "Missing from the package.";
    } else if (!/\.(?:md|markdown|txt)$/iu.test(path) ||
        path.split("/").some(part => part.startsWith(".") || part.toLowerCase() === "scripts")) {
      reason = "Attach separately if needed.";
    } else if (data.byteLength > maxFileBytes) {
      reason = "Exceeds 8 KiB per reference.";
    } else if (included.length >= maxFiles || totalBytes + data.byteLength > maxTotalBytes) {
      reason = "Exceeds the combined reference limit (6 files or 24 KiB).";
    } else {
      let text = "";
      try {
        text = decoder.decode(data);
      } catch {
        reason = "Requires a UTF-8 text copy.";
      }
      if (!reason && /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(text)) {
        reason = "Contains binary control characters.";
      }
      if (!reason) {
        if (included.length === 0) sections.push("## Reference material");
        sections.push(path + "\n\n" + text.replace(/\r\n?/gu, "\n").split("\n").map(line => "> " + line).join("\n"));
        included.push(path);
        totalBytes += data.byteLength;
      }
    }
    if (reason) omitted.push({ path, reason });
  }
  for (const path of relativeFiles.keys()) {
    if (!linked.has(path)) omitted.push({ path, reason: "No direct Markdown link in the instructions." });
  }
  return { prompt: sections.join("\n\n"), included, omitted };
}
