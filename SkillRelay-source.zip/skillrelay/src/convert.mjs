import { isMap, parseDocument, stringify } from "yaml";
import { limits, readZip, writeZip } from "./archive.mjs";
import { isPlatform, platforms } from "./platforms.mjs";
import { buildChatCopy } from "./chat-copy.mjs";

const utf8 = new TextEncoder();
const decoder = new TextDecoder("utf-8", { fatal: true });
const slugPattern = /^[a-z0-9]+(?:-[a-z0-9]+)*$/u;
const reservedClaudeNames = /anthropic|claude/giu;
const sharedKeys = new Set(["name", "description", "license", "compatibility", "metadata"]);

function parseSkill(bytes) {
  if (bytes.length > limits.markdown) throw new Error("SKILL.md exceeds 512 KiB.");
  let markdown;
  try {
    markdown = decoder.decode(bytes).replace(/\r\n?/g, "\n");
  } catch {
    throw new Error("Save SKILL.md as UTF-8 and try again.");
  }
  const opening = /^---[ \t]*\n/u.exec(markdown);
  const close = opening && /^---[ \t]*(?:\n|$)/mu.exec(markdown.slice(opening[0].length));
  if (!close || close.index > 16 * 1024) {
    throw new Error("SKILL.md needs a YAML header (up to 16 KiB) between two --- lines.");
  }
  const offset = opening[0].length;
  try {
    const yaml = parseDocument(markdown.slice(offset, offset + close.index), {
      uniqueKeys: true,
      stringKeys: true,
      prettyErrors: false,
    });
    if (yaml.errors.length || yaml.warnings.length || !isMap(yaml.contents)) {
      throw new Error("Expected a single YAML mapping with unique keys and standard values.");
    }
    return {
      fields: yaml.toJS({ mapAsMap: true, maxAliasCount: 0 }),
      body: markdown.slice(offset + close.index + close[0].length),
    };
  } catch (error) {
    throw new Error(`Invalid YAML in SKILL.md: ${error.message}`, { cause: error });
  }
}

function standardName(value, target) {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error("Add a nonempty name to the SKILL.md header.");
  }
  let name = value.normalize("NFKD").replace(/\p{Mark}/gu, "").toLowerCase();
  if (target === "claude") name = name.replace(reservedClaudeNames, "-");
  name = name.replace(/[^a-z0-9]+/gu, "-").replace(/^-+|-+$/gu, "").slice(0, 64).replace(/-$/u, "");
  if (!slugPattern.test(name)) {
    throw new Error("Choose a skill name that includes a Latin letter or number and works on the destination.");
  }
  return name;
}

function convertHeader(fields, target, notes) {
  const name = standardName(fields.get("name"), target);
  const description = fields.get("description");
  if (typeof description !== "string" || !description.trim() || [...description.trim()].length > 1024) {
    throw new Error("Give the skill a text description between 1 and 1,024 characters.");
  }
  if (target === "claude" && /<\/?[a-z][^>]*>/iu.test(description)) {
    throw new Error("Remove markup tags from the description before exporting to Claude.");
  }
  if (name !== fields.get("name")) {
    notes.push({ level: "change", text: `Renamed the skill folder to “${name}”. Review any instructions that mention the original folder.` });
  }
  const header = { name, description: description.trim() };
  for (const field of ["license", "compatibility"]) {
    if (!fields.has(field)) continue;
    const value = fields.get(field);
    if (typeof value === "string" && value.trim() && (field !== "compatibility" || [...value].length <= 500)) {
      header[field] = value;
    } else {
      notes.push({ level: "review", text: `Omitted “${field}” because its value falls outside the Agent Skills format.` });
    }
  }
  const metadata = fields.get("metadata");
  if (metadata instanceof Map && [...metadata.values()].every(value => typeof value === "string")) {
    header.metadata = Object.fromEntries(metadata);
  } else if (fields.has("metadata")) {
    notes.push({ level: "review", text: "Omitted metadata because Agent Skills expects a map of text values." });
  }
  const omitted = [...fields.keys()].filter(key => !sharedKeys.has(key) &&
    !(key === "disable-model-invocation" && typeof fields.get(key) === "boolean"));
  if (omitted.length) {
    notes.push({
      level: "review",
      text: "Removed nonportable header fields. Restore any matching behavior using the destination’s settings after reviewing it.",
      items: omitted,
    });
  }
  return header;
}

function requiresManualInvocation(bytes) {
  if (bytes.length > 16 * 1024) throw new Error("The OpenAI manifest exceeds 16 KiB. Review its invocation policy before converting.");
  try {
    const doc = parseDocument(decoder.decode(bytes), { uniqueKeys: true, prettyErrors: false });
    if (doc.errors.length || doc.warnings.length || !isMap(doc.contents)) throw new Error();
    const policy = doc.toJS({ mapAsMap: true, maxAliasCount: 0 }).get("policy");
    if (policy === undefined) return false;
    if (!(policy instanceof Map)) throw new Error();
    const value = policy.get("allow_implicit_invocation");
    if (value !== undefined && typeof value !== "boolean") throw new Error();
    return value === false;
  } catch {
    throw new Error("Could not read the invocation policy in agents/openai.yaml. Use a YAML map with true or false for allow_implicit_invocation.");
  }
}

function isJunk(path) {
  return path.toLowerCase().split("/").some(part =>
    [".git", ".hg", ".svn", "__macosx", ".ds_store", "thumbs.db"].includes(part) || part.startsWith("._")
  );
}

function isProviderFile(path) {
  return /^(agents\/openai\.ya?ml|\.mcp\.json|\.claude(?:\/|$)|\.codex(?:\/|$))/iu.test(path);
}

function looksExecutable(path) {
  return /(?:^|\/)scripts\//iu.test(path) ||
    /\.(?:applescript|bat|cmd|cjs|dll|exe|jar|js|mjs|ps1|py|rb|sh|ts|vbs|wasm|zsh)$/iu.test(path);
}

function reviewBody(body, paths, notes) {
  if (/\$\{(?:CLAUDE_SKILL_DIR|CLAUDE_SESSION_ID)\}|\$ARGUMENTS\b|!`|(?:^|\n)[ \t]*!```/mu.test(body)) {
    notes.push({ level: "review", text: "Instructions refer to Claude Code substitutions or dynamic command syntax. Review and adapt them before enabling the skill." });
  }
  if (/\bmcp__[a-z0-9_-]+__|\b(?:AskUserQuestion|WebSearch|code_interpreter|apply_patch)\b/iu.test(body)) {
    notes.push({ level: "review", text: "Instructions mention named tools. Check that the destination can perform those steps." });
  }
  const missing = new Set();
  for (const match of body.matchAll(/\]\((?:\.\/)?((?:assets|references|scripts)\/[^()\s#]+)(?:#[^\s)]*)?\)/gu)) {
    if (!paths.has(match[1])) missing.add(match[1]);
  }
  if (missing.size) notes.push({ level: "review", text: "Some linked skill files were missing from the export.", items: [...missing] });
}

export async function convertSkill(bytes, filename, target) {
  if (!isPlatform(target)) throw new Error("Choose chatgpt or claude as the destination.");
  let input;
  if (/\.zip$/iu.test(filename)) {
    input = await readZip(bytes);
  } else if (/\.md$/iu.test(filename)) {
    input = new Map([["SKILL.md", bytes]]);
  } else {
    throw new Error("Add a .zip skill bundle or a .md skill file.");
  }
  const candidates = [...input.keys()].filter(path =>
    !isJunk(path) && /(?:^|\/)skill\.md$/iu.test(path)
  );
  if (candidates.length !== 1) {
    throw new Error(candidates.length
      ? "This ZIP contains several skills. Package one skill folder at a time."
      : "The ZIP must contain one SKILL.md file.");
  }
  const [skillPath] = candidates;
  const root = skillPath.slice(0, skillPath.lastIndexOf("/") + 1);
  const { fields, body } = parseSkill(input.get(skillPath));
  if (!body.trim()) throw new Error("Add Markdown instructions below the SKILL.md header.");
  const notes = [];
  const header = convertHeader(fields, target, notes);
  const relative = new Map();
  const removed = [];
  let manualOnly = fields.get("disable-model-invocation") === true;
  if (fields.has("disable-model-invocation") && typeof fields.get("disable-model-invocation") !== "boolean") {
    throw new Error("In SKILL.md, use true or false for disable-model-invocation.");
  }
  let ignored = 0;
  for (const [path, data] of input) {
    if (path === skillPath) continue;
    if (!path.startsWith(root) || isJunk(path)) {
      ignored += 1;
      continue;
    }
    const subpath = path.slice(root.length);
    if (/^agents\/openai\.ya?ml$/iu.test(subpath)) {
      manualOnly = requiresManualInvocation(data) || manualOnly;
    }
    if (isProviderFile(subpath)) removed.push(subpath);
    else relative.set(subpath, data);
  }
  if (ignored) notes.push({ level: "change", text: `Skipped ${ignored} file(s) outside the skill or generated by system tools.` });
  if (removed.length) {
    notes.push({ level: "review", text: "Omitted host configuration files. Recreate any required tool setup in the destination after review.", items: removed });
  }
  const scripts = [...relative.keys()].filter(looksExecutable);
  if (scripts.length) {
    notes.push({
      level: "review",
      text: "Included these code files as-is. Review them and check runtime dependencies before running them.",
      items: scripts,
    });
  }
  reviewBody(body, relative, notes);
  if (manualOnly) {
    if (target === "claude") header["disable-model-invocation"] = true;
    notes.push({ level: "change", text: "Preserved manual invocation for " + (target === "claude" ? "Claude Code" : "Codex") + ". Check the invocation settings if installing in another client." });
  }
  const markdown = `---\n${stringify(header, { lineWidth: 0 })}---\n${body.endsWith("\n") ? body : body + "\n"}`;
  const files = new Map([[`${header.name}/SKILL.md`, utf8.encode(markdown)]]);
  for (const [path, data] of relative) files.set(`${header.name}/${path}`, data);
  if (manualOnly && target === "chatgpt") {
    files.set(`${header.name}/agents/openai.yaml`, utf8.encode("policy:\n  allow_implicit_invocation: false\n"));
  }
  return {
    name: header.name,
    description: header.description,
    target,
    targetName: platforms[target],
    markdown,
    instructions: body.trim(),
    chatCopy: buildChatCopy(body.trim(), relative),
    notes,
    files: [...files.keys()].sort(),
    filename: `${header.name}-for-${target}.zip`,
    zip: await writeZip(files),
  };
}
