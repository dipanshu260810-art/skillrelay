import { randomUUID } from "node:crypto";
import { lstat, mkdir, rename, unlink, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { handoffMaxBytes, parseHandoff, serializeHandoff } from "./handoff.mjs";
import { readBoundedFile } from "./local-io.mjs";

const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u;

export async function saveHandoff(inbox, input) {
  const data = serializeHandoff(input);
  await mkdir(inbox, { mode: 0o700, recursive: true });
  const id = randomUUID();
  const temp = join(inbox, `.${id}.tmp`);
  await writeFile(temp, data, { mode: 0o600, flag: "wx" });
  try {
    await rename(temp, join(inbox, `${id}.json`));
  } catch (error) {
    await unlink(temp).catch(() => {});
    throw error;
  }
  return id;
}

export async function loadHandoff(inbox, id) {
  if (typeof id !== "string" || !uuidPattern.test(id)) throw new Error("Enter a valid handoff ID.");
  const path = join(inbox, `${id}.json`);
  try {
    if (!(await lstat(path)).isFile()) throw new Error("The handoff must be a regular file.");
    const bytes = await readBoundedFile(path, handoffMaxBytes, { noLinks: true });
    return parseHandoff(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch (error) {
    if (error.code === "ENOENT") throw new Error("That handoff ID is not in this inbox.");
    throw error;
  }
}
