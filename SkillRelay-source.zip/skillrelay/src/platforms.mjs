export const platforms = Object.freeze({ chatgpt: "ChatGPT", claude: "Claude" });

export function isPlatform(value) {
  return typeof value === "string" && Object.hasOwn(platforms, value);
}

export function otherPlatform(value) {
  return value === "claude" ? "chatgpt" : "claude";
}
