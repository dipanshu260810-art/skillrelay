# Chat handoff and local MCP

## Any chat with copy and paste

1. In the web app, open **Chat handoff** and pick the direction.
2. Write the next request in your own words. Put selected source text in **Context**.
3. Select **Preview handoff**, review it, then copy the prompt into the other chat. For attachments, upload the files you choose separately through that chat.

**Download JSON** saves a draft. **Open saved handoff** reopens that file in SkillRelay. The app previews the exact prompt you can share. Both assistants retain their own accounts and chat histories.

## Two local MCP clients

The MCP transport is `stdio`. Install Node.js 22 or newer and run `npm ci` in this checkout. Configure each local client with the same absolute path to the SkillRelay inbox. Replace both example paths below and use the full path to the Node executable if the client cannot find `node`.

**Codex CLI**

```sh
codex mcp add skillrelay -- node "/absolute/path/to/skillrelay/bin/skillrelay.mjs" mcp --inbox "/absolute/path/to/private-inbox"
codex mcp list
```

Use the normal Codex sign-in and the client's MCP controls. See [OpenAI’s MCP setup](https://learn.chatgpt.com/docs/extend/mcp).

**Claude Code**

```sh
claude mcp add --transport stdio skillrelay -- node "/absolute/path/to/skillrelay/bin/skillrelay.mjs" mcp --inbox "/absolute/path/to/private-inbox"
claude mcp list
```

This setup is for eligible Claude users in a local Claude Code session. See [Anthropic’s MCP setup](https://code.claude.com/docs/en/mcp#option-3-add-a-local-stdio-server).

Then ask one client to send the reviewed handoff and return its ID. In the other, ask it to read that ID. The second client can save a new handoff with its reply. Two separate MCP clients connected to the same directory are covered by integration tests in this repository.

Handoff JSON is stored on disk in the selected inbox as plain text. Choose a folder private to you and outside version control. Delete saved files you no longer need. The server takes no account tokens, calls no model APIs, and exposes no network endpoint. Use the copy-and-paste workflow for consumer web chats. ChatGPT web custom MCP connections have separate account requirements and use remote connections. [OpenAI web MCP availability](https://help.openai.com/en/articles/12584461-connecting-custom-mcp-servers-in-chatgpt), [Anthropic local and remote connectors](https://support.claude.com/en/articles/11725091-when-to-use-desktop-and-web-connectors)

## Move drafts between the browser and MCP

Export a JSON draft from the browser and import it into the inbox with the CLI. Use the printed ID in either local client.

```sh
node bin/skillrelay.mjs handoff import handoff-to-claude.skillrelay.json --inbox "/absolute/path/to/private-inbox"
```

To reopen a locally saved handoff in the browser, export it to a JSON file and open it in **Chat handoff**. Substitute the actual ID in the command.

```sh
node bin/skillrelay.mjs handoff export HANDOFF_ID --inbox "/absolute/path/to/private-inbox" --out saved.skillrelay.json
```
