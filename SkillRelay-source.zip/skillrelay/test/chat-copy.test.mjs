import assert from "node:assert/strict";
import { test } from "node:test";
import { buildChatCopy } from "../src/chat-copy.mjs";

const enc = new TextEncoder();
const file = (path, text) => [path, enc.encode(text)];

test("ordinary chats can use an instruction with a bundled reference", () => {
  const instructions = "Use [the form](./references/form.md#steps), then [the same form](references/form.md).";
  const files = new Map([file("references/form.md", "# Steps\r\nChoose an owner."), file("assets/extra.txt", "unlinked")]);
  const result = buildChatCopy(instructions, files);
  assert.equal(result.prompt, instructions + "\n\n## Reference material\n\nreferences/form.md\n\n> # Steps\n> Choose an owner.");
  assert.deepEqual(result.included, ["references/form.md"]);
  assert.deepEqual(result.omitted.map(entry => entry.path), ["assets/extra.txt"]);
  assert.doesNotMatch(result.prompt, /unlinked/u);
});

test("reports needed files without trying to read links outside the skill or running code", () => {
  const instructions = [
    "[missing](references/missing.md) [code](scripts/helper.txt) [pic](assets/diagram.png)",
    "[outside](../notes.md) [remote](https://example.com/notes.md) [absolute](/tmp/private.md)",
    "[sample](<references/field notes.txt>) [alias](references/field%20notes.txt)",
    "```md", "[demo](example.md)", "```", "Inline `[demo](example.md)`.",
  ].join("\n");
  const files = new Map([
    file("scripts/helper.txt", "script contents"), file("assets/diagram.png", "binary"),
    file("references/field notes.txt", "Use a ledger."), file("example.md", "demo contents"),
  ]);
  const result = buildChatCopy(instructions, files);
  assert.deepEqual(result.included, ["references/field notes.txt"]);
  assert.deepEqual(result.omitted.map(item => item.path),
    ["references/missing.md", "scripts/helper.txt", "assets/diagram.png", "example.md"]);
  assert.doesNotMatch(result.prompt, /script contents|demo contents/u);
});

test("omits invalid UTF-8, disguised binaries and oversized text in full", () => {
  const files = new Map([
    ["bad.txt", new Uint8Array([255])],
    file("binary.txt", "ok\u0000hidden"),
    file("large.md", "界".repeat(3000)),
  ]);
  const instructions = [...files.keys()].map(key => "[read](" + key + ")").join(" ");
  const result = buildChatCopy(instructions, files);
  assert.equal(result.prompt, instructions);
  assert.deepEqual(result.included, []);
  assert.equal(result.omitted.length, 3);
  assert.equal(result.omitted[2].reason, "Exceeds 8 KiB per reference.");
});

test("limits combined bytes and count while retaining original instructions", () => {
  const files = new Map(Array.from({ length: 7 }, (_, i) => file(i + ".md", "x".repeat(8192))));
  const instructions = [...files.keys()].map(key => "[](" + key + ")").join(" ");
  const byteLimited = buildChatCopy(instructions, files);
  assert.equal(byteLimited.included.length, 3);
  assert.equal(byteLimited.omitted.length, 4);
  assert.ok(byteLimited.prompt.startsWith(instructions));
  const short = new Map([...files.keys()].map(path => file(path, "a")));
  assert.equal(buildChatCopy(instructions, short).included.length, 6);
});
