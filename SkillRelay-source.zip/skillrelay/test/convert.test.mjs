import assert from "node:assert/strict";
import { test } from "node:test";
import { Uint8ArrayReader, Uint8ArrayWriter, ZipWriter } from "@zip.js/zip.js";
import { parse } from "yaml";
import { limits, readZip, writeZip } from "../src/archive.mjs";
import { convertSkill } from "../src/convert.mjs";

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const binary = Uint8Array.from([0, 255, 128, 1, 0, 13, 10]);
const body = "# Organize notes\n\nRead [the template](references/template.md).\n";
const source = (header, markdown = body) => encoder.encode(`---\n${header}\n---\n${markdown}`);
const validHeader = "name: organize-notes\ndescription: Organize classroom notes.";
const zipFiles = (...files) => writeZip(new Map(files.map(([path, value]) =>
  [path, typeof value === "string" ? encoder.encode(value) : value]
)));

test("Claude to ChatGPT keeps supporting bytes and reports unsupported fields", async () => {
  const input = await zipFiles(
    ["download-v1/original/SKILL.md", source(`${validHeader}\nhooks:\n  Stop: []\nallowed-tools: Bash\ndisable-model-invocation: true`)],
    ["download-v1/original/references/template.md", "Template"],
    ["download-v1/original/assets/data.bin", binary],
    ["download-v1/original/scripts/helper.py", "print('demo')"],
    ["download-v1/other.txt", "Outside the skill folder"],
  );
  const result = await convertSkill(input, "download.zip", "chatgpt");
  const files = await readZip(result.zip);
  assert.equal(result.filename, "organize-notes-for-chatgpt.zip");
  assert.deepEqual(files.get("organize-notes/assets/data.bin"), binary);
  assert.equal(decoder.decode(files.get("organize-notes/references/template.md")), "Template");
  assert.match(result.markdown, /Read \[the template\]/);
  assert.doesNotMatch(result.markdown, /hooks:|allowed-tools:|disable-model-invocation:/);
  assert.equal(files.size, 5);
  assert.deepEqual(parse(decoder.decode(files.get("organize-notes/agents/openai.yaml"))), {
    policy: { allow_implicit_invocation: false },
  });
  const reverse = await convertSkill(result.zip, result.filename, "claude");
  assert.match(reverse.markdown, /disable-model-invocation: true/);
  assert.ok(reverse.chatCopy.included.includes("references/template.md"));
  assert.ok(result.notes.some(note => note.items?.includes("hooks")));
  assert.ok(result.notes.some(note => note.items?.includes("scripts/helper.py")));
  assert.ok(result.notes.some(note => note.text.includes("manual invocation")));
});

test("an ambiguous manual invocation setting must be fixed before export", async () => {
  for (const manifest of ["policy: 3", "policy:\n  allow_implicit_invocation: 'false'", "bogus: [["]) {
    const input = await zipFiles(["SKILL.md", source(validHeader)], ["agents/openai.yaml", manifest]);
    await assert.rejects(convertSkill(input, "notes.zip", "claude"), /invocation policy/);
  }
  const invalid = source(validHeader + "\ndisable-model-invocation: 'true'");
  await assert.rejects(convertSkill(invalid, "SKILL.md", "chatgpt"), /use true or false/);
});

test("ChatGPT to Claude packages one named directory and removes host manifests", async () => {
  const input = await zipFiles(
    ["skill.md", source("name: Claude Café Notes\ndescription: >-\n  Summarize records\n  for a team.\nlicense: MIT\nmetadata:\n  version: '1.0'")],
    ["agents/openai.yaml", "interface:\n  display_name: Notes"],
    ["references/template.md", "sample"],
  );
  const result = await convertSkill(input, "notes.zip", "claude");
  const files = await readZip(result.zip);
  assert.equal(result.filename, "cafe-notes-for-claude.zip");
  assert.deepEqual([...files.keys()], ["cafe-notes/SKILL.md", "cafe-notes/references/template.md"]);
  assert.deepEqual(parse(result.markdown.split("---\n")[1]), {
    name: "cafe-notes", description: "Summarize records for a team.", license: "MIT", metadata: { version: "1.0" },
  });
  assert.ok(result.notes.some(note => note.items?.includes("agents/openai.yaml")));
});

test("round trips neutral instructions and binary assets", async () => {
  const input = await zipFiles(
    ["original/SKILL.md", source(validHeader)],
    ["original/references/template.md", "rows\n"],
    ["original/assets/data.bin", binary],
  );
  const first = await convertSkill(input, "source.zip", "claude");
  const second = await convertSkill(first.zip, first.filename, "chatgpt");
  assert.equal(second.markdown, first.markdown);
  assert.equal(second.instructions, body.trim());
  assert.deepEqual(await readZip(second.zip), await readZip(first.zip));
});

test("opens BOM and Windows line endings in a standalone skill", async () => {
  const markdown = encoder.encode("\uFEFF---\r\nname: notes\r\ndescription: A short skill.\r\n---\r\n# Instructions\r\n");
  const result = await convertSkill(markdown, "SKILL.MD", "chatgpt");
  assert.equal(result.instructions, "# Instructions");
  assert.deepEqual(result.files, ["notes/SKILL.md"]);
});

test("warns about missing references and host-specific instructions", async () => {
  const markdown = "# Notes\n\nOpen [this](assets/missing.txt). Use `$ARGUMENTS` with `mcp__notes__read`.\n";
  const result = await convertSkill(source(validHeader, markdown), "SKILL.md", "chatgpt");
  assert.ok(result.notes.some(note => note.items?.includes("assets/missing.txt")));
  assert.ok(result.notes.some(note => note.text.includes("Claude Code")));
  assert.ok(result.notes.some(note => note.text.includes("named tools")));
});

test("rejects malformed YAML, aliases, and missing instruction content", async () => {
  for (const header of [
    "name: [one, two",
    "name: notes\nname: notes\n" + validHeader,
    "name: &n notes\ndescription: *n",
    "name: notes\ndescription: 5",
  ]) {
    await assert.rejects(convertSkill(source(header), "SKILL.md", "chatgpt"), /YAML|description/);
  }
  await assert.rejects(convertSkill(source(validHeader, ""), "SKILL.md", "chatgpt"), /Markdown instructions/);
  await assert.rejects(convertSkill(new Uint8Array([255]), "SKILL.md", "chatgpt"), /UTF-8/);
  await assert.rejects(convertSkill(new Uint8Array(limits.markdown + 1), "SKILL.md", "chatgpt"), /512 KiB/);
});

test("identifies zero or multiple skills in a ZIP", async () => {
  const empty = await zipFiles(["README.md", "No skill here"]);
  await assert.rejects(convertSkill(empty, "test.zip", "chatgpt"), /contain one SKILL.md/);
  const many = await zipFiles(["a/SKILL.md", source(validHeader)], ["b/SKILL.md", source(validHeader)]);
  await assert.rejects(convertSkill(many, "test.zip", "claude"), /several skills/);
});

async function fixtureZip(entries) {
  const writer = new ZipWriter(new Uint8ArrayWriter(), { useWebWorkers: false, level: 0 });
  for (const [filename, value, options] of entries) {
    await writer.add(filename, new Uint8ArrayReader(value), options);
  }
  return writer.close();
}

test("rejects traversal, absolute paths, and case collisions", async () => {
  for (const path of ["../bad.md", "C:/bad.md", "some\\bad.md", "name/CON.txt"]) {
    const bytes = await fixtureZip([[path, binary]]);
    await assert.rejects(readZip(bytes), /unsafe|cannot be used safely/i);
  }
  const collision = await fixtureZip([["a/File.txt", binary], ["a/file.txt", binary]]);
  await assert.rejects(readZip(collision), /conflicting paths/);
});

test("rejects symlinks and corrupted entry data", async () => {
  const linked = await fixtureZip([["some-link", encoder.encode("elsewhere"), { unixMode: 0o120777 }]]);
  await assert.rejects(readZip(linked), /symbolic link|special file/);
  const corrupt = await fixtureZip([["a.bin", binary]]);
  const start = 30 + new DataView(corrupt.buffer, corrupt.byteOffset).getUint16(26, true) +
    new DataView(corrupt.buffer, corrupt.byteOffset).getUint16(28, true);
  corrupt[start] ^= 1;
  await assert.rejects(readZip(corrupt), /CRC|signature|corrupt/i);
});

test("enforces compressed and entry size caps before extraction", async () => {
  await assert.rejects(readZip(new Uint8Array(limits.zip + 1)), /size limit/);
  const oversized = await fixtureZip([["big.bin", new Uint8Array(limits.entry + 1)]]);
  await assert.rejects(readZip(oversized), /ZIP entry exceeds/);
});
