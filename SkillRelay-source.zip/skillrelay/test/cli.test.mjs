import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";
import { promisify } from "node:util";
import { readZip } from "../src/archive.mjs";
import { serializeHandoff } from "../src/handoff.mjs";

const run = promisify(execFile);
const cli = fileURLToPath(new URL("../bin/skillrelay.mjs", import.meta.url));
const sample = fileURLToPath(new URL("../examples/meeting-brief/SKILL.md", import.meta.url));

test("the CLI produces a ZIP and refuses to overwrite it", async t => {
  const dir = await mkdtemp(join(tmpdir(), "skillrelay-cli-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const output = join(dir, "package.zip");
  const args = [cli, "convert", sample, "--to", "claude", "--out", output];
  const first = await run(process.execPath, args);
  assert.match(first.stdout, /Wrote .*Claude package/);
  const files = await readZip(new Uint8Array(await readFile(output)));
  assert.deepEqual([...files.keys()], ["meeting-brief/SKILL.md"]);
  await assert.rejects(run(process.execPath, args), /already exists/);
});

test("the CLI imports browser JSON and exports a receiving prompt", async t => {
  const dir = await mkdtemp(join(tmpdir(), "skillrelay-cli-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const file = join(dir, "handoff.json");
  const inbox = join(dir, "inbox");
  await writeFile(file, serializeHandoff({
    from: "claude", to: "chatgpt", title: "Summarize", request: "Write two sentences.", context: "Notes",
  }));
  const id = (await run(process.execPath, [cli, "handoff", "import", file, "--inbox", inbox])).stdout.trim();
  const { stdout } = await run(process.execPath, [cli, "handoff", "prompt", id, "--inbox", inbox]);
  assert.match(stdout, /Write two sentences\./);
  assert.match(stdout, /> Notes/);
});
