import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { formatHandoff, makeHandoff, parseHandoff, serializeHandoff } from "../src/handoff.mjs";
import { loadHandoff, saveHandoff } from "../src/inbox.mjs";

const draft = {
  from: "chatgpt",
  to: "claude",
  title: "Review the guide",
  request: "Identify missing steps.",
  context: "First draft\n---\nUnverified claims",
};

test("handoff JSON round trips and marks the quoted context", () => {
  assert.deepEqual(parseHandoff(serializeHandoff(draft)), makeHandoff(draft));
  assert.match(formatHandoff(draft), /from ChatGPT to Claude/);
  assert.match(formatHandoff(draft), /> First draft\n> ---\n> Unverified claims/);
});

test("handoffs reject unknown schema versions, oversized content, and bad directions", () => {
  for (const input of ["[]", "{", '{"schema":"skillrelay.handoff","version":2}']) {
    assert.throws(() => parseHandoff(input), /JSON|version 1/);
  }
  assert.throws(() => makeHandoff({ ...draft, to: "chatgpt" }), /different assistants/);
  assert.throws(() => makeHandoff({ ...draft, title: "A\nB" }), /one line/);
  assert.throws(() => makeHandoff({ ...draft, request: " " }), /request/);
  assert.throws(() => serializeHandoff({ ...draft, context: "界".repeat(23000) }), /64 KiB/);
});

async function temporaryInbox(t) {
  const temp = await mkdtemp(join(tmpdir(), "skillrelay-"));
  t.after(() => rm(temp, { recursive: true, force: true }));
  return join(temp, "inbox");
}

test("concurrent saves produce separate handoff IDs", async t => {
  const inbox = await temporaryInbox(t);
  const [first, second] = await Promise.all([
    saveHandoff(inbox, draft),
    saveHandoff(inbox, { ...draft, request: "Write a reply." }),
  ]);
  assert.notEqual(first, second);
  assert.equal((await loadHandoff(inbox, first)).request, draft.request);
  assert.equal((await loadHandoff(inbox, second)).request, "Write a reply.");
  await assert.rejects(loadHandoff(inbox, "../secrets"), /valid handoff ID/);
});

test("two MCP clients exchange a handoff and a reply through a shared inbox", { timeout: 15_000 }, async t => {
  const inbox = await temporaryInbox(t);
  const cli = fileURLToPath(new URL("../bin/skillrelay.mjs", import.meta.url));
  const connect = async name => {
    const client = new Client({ name, version: "1.0.0" });
    t.after(() => client.close());
    await client.connect(new StdioClientTransport({
      command: process.execPath,
      args: [cli, "mcp", "--inbox", inbox],
      stderr: "pipe",
    }));
    return client;
  };
  const [left, right] = await Promise.all([connect("sender"), connect("receiver")]);
  const { tools } = await left.listTools();
  assert.deepEqual(tools.map(tool => tool.name).sort(), ["read_handoff", "send_handoff"]);
  const sent = await left.callTool({ name: "send_handoff", arguments: draft });
  assert.ok(sent.structuredContent.id);
  const received = await right.callTool({ name: "read_handoff", arguments: { id: sent.structuredContent.id } });
  assert.deepEqual(received.structuredContent.handoff, makeHandoff(draft));
  const reply = await right.callTool({
    name: "send_handoff",
    arguments: { from: "claude", to: "chatgpt", title: "Review complete", request: "Revise the draft.", context: "Add a test command." },
  });
  const response = await left.callTool({ name: "read_handoff", arguments: { id: reply.structuredContent.id } });
  assert.equal(response.structuredContent.handoff.context, "Add a test command.");
  const bad = await right.callTool({ name: "read_handoff", arguments: { id: "../file" } });
  assert.equal(bad.isError, true);
});
