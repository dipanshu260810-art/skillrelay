import { limits, writeZip } from "../src/archive.mjs";
import { convertSkill } from "../src/convert.mjs";
import { formatHandoff, handoffMaxBytes, makeHandoff, parseHandoff, serializeHandoff } from "../src/handoff.mjs";
import { otherPlatform, platforms } from "../src/platforms.mjs";
import sampleSkill from "../examples/meeting-brief/SKILL.md";
import sampleReference from "../examples/meeting-brief/references/brief.md";

const byId = id => document.getElementById(id);
const tabs = [...document.querySelectorAll('[role="tab"]')];
const converter = { from: "claude", file: null, package: null, busy: false };
const handoff = { from: "chatgpt", output: null };
const fileInput = byId("skill-file");
const sourceModes = [...document.querySelectorAll('input[name="skill-source"]')];
const pastedSkill = byId("pasted-skill");
const dropZone = byId("drop-zone");
const form = byId("handoff-form");
let toastTimer;

const install = {
  chatgpt: {
    text: "Use Plugins → Skills if your workspace allows uploads. You can also copy the instructions into a regular chat.",
    link: "https://help.openai.com/en/articles/20001066-skills-in-chatgpt",
  },
  claude: {
    text: "On an eligible Claude account, open Customize → Skills and upload the ZIP.",
    link: "https://support.claude.com/en/articles/12512180-use-skills-in-claude",
  },
};

function setError(id, message = "") {
  const error = byId(id);
  error.textContent = message;
  error.hidden = !message;
}

function notify(message) {
  byId("announcement").textContent = message;
  const toast = byId("toast");
  toast.textContent = message;
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.hidden = true; }, 3600);
}

function selectTab(tab, focus = false) {
  for (const candidate of tabs) {
    const active = candidate === tab;
    candidate.setAttribute("aria-selected", String(active));
    candidate.tabIndex = active ? 0 : -1;
    byId(candidate.getAttribute("aria-controls")).hidden = !active;
  }
  if (focus) tab.focus();
}

for (const [index, tab] of tabs.entries()) {
  tab.addEventListener("click", () => selectTab(tab));
  tab.addEventListener("keydown", event => {
    const positions = { ArrowLeft: (index + tabs.length - 1) % tabs.length, ArrowRight: (index + 1) % tabs.length, Home: 0, End: tabs.length - 1 };
    if (!Object.hasOwn(positions, event.key)) return;
    event.preventDefault();
    selectTab(tabs[positions[event.key]], true);
  });
}

function updateDirection(section, from) {
  const container = document.querySelector(`[data-direction="${section}"]`);
  const to = otherPlatform(from);
  container.querySelectorAll(".platform").forEach((element, index) => {
    const key = index ? to : from;
    const icon = element.querySelector(".provider-icon");
    element.querySelector("strong").textContent = platforms[key];
    icon.dataset.platform = key;
    icon.textContent = key === "claude" ? "C" : "G";
  });
  if (section === "converter") {
    byId("convert-button").firstChild.textContent = `Convert to ${platforms[to]} `;
    byId("install-guide").textContent = install[to].text;
    byId("install-docs").href = install[to].link;
  }
}

function refreshConverterControls() {
  const hasInput = byId("paste-panel").hidden ? Boolean(converter.file) : Boolean(pastedSkill.value.trim());
  byId("convert-button").disabled = converter.busy || !hasInput;
  byId("choose-skill").disabled = converter.busy;
  pastedSkill.disabled = converter.busy;
  for (const mode of sourceModes) mode.disabled = converter.busy;
  byId("clear-skill").disabled = converter.busy;
  byId("sample-skill").disabled = converter.busy;
  document.querySelector('[data-direction="converter"] .swap').disabled = converter.busy;
}

function clearConversion() {
  converter.package = null;
  byId("result").hidden = true;
  setError("convert-error");
}

function setSourceMode(value) {
  byId("paste-panel").hidden = value !== "paste";
  byId("file-panel").hidden = value !== "file";
  for (const mode of sourceModes) mode.checked = mode.value === value;
  clearConversion();
  refreshConverterControls();
}

for (const mode of sourceModes) {
  mode.addEventListener("change", () => setSourceMode(mode.value));
}
pastedSkill.addEventListener("input", () => {
  clearConversion();
  refreshConverterControls();
});

function selectFile(file) {
  clearConversion();
  if (file) {
    const markdown = /\.md$/iu.test(file.name);
    if (!markdown && !/\.zip$/iu.test(file.name)) {
      setError("convert-error", "Choose a skill ZIP or a .md file.");
      file = null;
    } else if (!file.size || file.size > (markdown ? limits.markdown : limits.zip)) {
      setError("convert-error", markdown ? "Choose a SKILL.md file up to 512 KiB." : "Choose a nonempty ZIP up to 24 MiB.");
      file = null;
    }
  }
  converter.file = file;
  byId("selected-skill").hidden = !file;
  byId("selected-name").textContent = file?.name ?? "";
  byId("selected-meta").textContent = file ? `${Math.max(1, Math.ceil(file.size / 1024))} KiB · Ready to convert` : "";
  refreshConverterControls();
}

function updateCopyPreview(result) {
  const { included, omitted, prompt } = result.chatCopy;
  const includeText = byId("copy-references").checked;
  byId("skill-instructions").value = includeText ? prompt : result.instructions;
  const hint = byId("copy-files");
  const listed = byId("copy-omitted");
  const hasResources = result.files.length > 1;
  byId("copy-option").hidden = !included.length;
  hint.hidden = !hasResources && !omitted.length;
  hint.textContent = includeText
    ? `Preview includes ${included.length} linked text ${included.length === 1 ? "file" : "files"}. Review the text before sharing it.`
    : "If your task needs supporting files, review the package contents and attach the relevant files separately.";
  listed.hidden = !omitted.length || (included.length > 0 && !includeText);
  listed.replaceChildren(...omitted.map(({ path, reason }) => {
    const item = document.createElement("li");
    item.textContent = `${path} — ${reason}`;
    return item;
  }));
}
byId("copy-references").addEventListener("change", () => {
  if (converter.package) updateCopyPreview(converter.package);
});

function showResult(result) {
  converter.package = result;
  byId("result-name").textContent = result.filename;
  byId("result-type").textContent = result.notes.some(note => note.level === "review") ? "Package ready for review" : "Package ready";
  byId("result-summary").textContent = `${result.files.length} ${result.files.length === 1 ? "file" : "files"} for ${result.targetName}`;
  byId("copy-references").checked = false;
  updateCopyPreview(result);
  byId("copy-skill").disabled = !result.instructions;
  const report = result.notes.length ? result.notes : [{ text: "The package passed the format checks. Try it with a simple task after installing." }];
  byId("report-list").replaceChildren(...report.map(note => {
    const item = document.createElement("li");
    item.dataset.review = note.level ?? "pass";
    item.textContent = note.text;
    if (note.items?.length) {
      const details = document.createElement("ul");
      for (const name of note.items) {
        const detail = document.createElement("li");
        detail.textContent = name;
        details.append(detail);
      }
      item.append(details);
    }
    return item;
  }));
  byId("file-list").replaceChildren(...result.files.map(name => {
    const item = document.createElement("li");
    item.textContent = name;
    return item;
  }));
  byId("result").hidden = false;
  byId("announcement").textContent = `Package ready for ${result.targetName}.`;
  if (!byId("converter").hidden) byId("result-name").focus();
}

async function convertSelected() {
  if (byId("convert-button").disabled || converter.busy) return;
  converter.busy = true;
  converter.package = null;
  byId("result").hidden = true;
  byId("convert-button").firstChild.textContent = "Converting… ";
  byId("announcement").textContent = "Converting skill.";
  setError("convert-error");
  refreshConverterControls();
  try {
    const file = byId("paste-panel").hidden
      ? converter.file
      : new File([pastedSkill.value], "SKILL.md", { type: "text/markdown" });
    if (/\.md$/iu.test(file.name) && file.size > limits.markdown) {
      throw new Error("SKILL.md exceeds 512 KiB. Shorten the instructions and try again.");
    }
    const result = await convertSkill(new Uint8Array(await file.arrayBuffer()), file.name, otherPlatform(converter.from));
    showResult(result);
  } catch (error) {
    setError("convert-error", error.message);
  } finally {
    converter.busy = false;
    updateDirection("converter", converter.from);
    refreshConverterControls();
  }
}

byId("choose-skill").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", () => {
  if (fileInput.files.length) selectFile(fileInput.files[0]);
  fileInput.value = "";
});
byId("clear-skill").addEventListener("click", () => {
  selectFile(null);
  byId("choose-skill").focus();
});
for (const type of ["dragenter", "dragover"]) {
  dropZone.addEventListener(type, event => {
    event.preventDefault();
    if (!converter.busy && event.dataTransfer.types.includes("Files")) dropZone.classList.add("active");
  });
}
dropZone.addEventListener("dragleave", event => {
  if (!dropZone.contains(event.relatedTarget)) dropZone.classList.remove("active");
});
dropZone.addEventListener("drop", event => {
  event.preventDefault();
  dropZone.classList.remove("active");
  if (converter.busy) return;
  if (event.dataTransfer.files.length !== 1) {
    setError("convert-error", "Drop one skill bundle at a time.");
  } else {
    selectFile(event.dataTransfer.files[0]);
  }
});
for (const type of ["dragover", "drop"]) {
  window.addEventListener(type, event => {
    if (event.dataTransfer.types.includes("Files")) event.preventDefault();
  });
}

byId("sample-skill").addEventListener("click", async () => {
  if (converter.busy) return;
  setSourceMode("file");
  converter.busy = true;
  refreshConverterControls();
  try {
    const enc = new TextEncoder();
    const zip = await writeZip(new Map([
      ["meeting-brief/SKILL.md", enc.encode(sampleSkill)],
      ["meeting-brief/references/brief.md", enc.encode(sampleReference)],
    ]));
    selectFile(new File([zip], "meeting-brief.zip", { type: "application/zip" }));
  } catch (error) {
    selectFile(null);
    setError("convert-error", error.message);
  } finally {
    converter.busy = false;
    refreshConverterControls();
  }
  if (converter.file) await convertSelected();
});
byId("convert-button").addEventListener("click", convertSelected);
document.querySelector('[data-direction="converter"] .swap').addEventListener("click", () => {
  converter.from = otherPlatform(converter.from);
  updateDirection("converter", converter.from);
  clearConversion();
  refreshConverterControls();
  byId("announcement").textContent = `Converting from ${platforms[converter.from]} to ${platforms[otherPlatform(converter.from)]}.`;
});

function download(filename, data, type) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 15_000);
}

async function copyFrom(element, message) {
  try {
    await navigator.clipboard.writeText(element.value);
    notify(message);
  } catch {
    element.focus();
    element.select();
    try {
      if (document.execCommand("copy")) {
        notify(message);
        return;
      }
    } catch {
      // The selected text is still available for keyboard copy.
    }
    notify("Text selected. Use your device’s Copy command.");
  }
}

byId("download-zip").addEventListener("click", () => {
  const result = converter.package;
  if (result) {
    download(result.filename, result.zip, "application/zip");
    notify("ZIP sent to browser downloads.");
  }
});
byId("copy-skill").addEventListener("click", () => copyFrom(byId("skill-instructions"), "Instructions copied."));

function clearHandoffPreview() {
  handoff.output = null;
  byId("handoff-result").hidden = true;
  setError("handoff-error");
}

function showHandoff(input) {
  const output = makeHandoff(input);
  const json = serializeHandoff(output);
  handoff.output = { json, to: output.to };
  byId("handoff-preview").value = formatHandoff(output);
  byId("handoff-result").hidden = false;
  if (!byId("handoff").hidden) byId("handoff-result-title").focus();
}

document.querySelector('[data-direction="handoff"] .swap').addEventListener("click", () => {
  handoff.from = otherPlatform(handoff.from);
  updateDirection("handoff", handoff.from);
  clearHandoffPreview();
  byId("announcement").textContent = `Handoff from ${platforms[handoff.from]} to ${platforms[otherPlatform(handoff.from)]}.`;
});
form.addEventListener("input", clearHandoffPreview);
form.addEventListener("submit", event => {
  event.preventDefault();
  clearHandoffPreview();
  const fields = Object.fromEntries(new FormData(form));
  try {
    showHandoff({ ...fields, from: handoff.from, to: otherPlatform(handoff.from) });
  } catch (error) {
    setError("handoff-error", error.message);
  }
});
const handoffInput = byId("handoff-file");
byId("import-handoff").addEventListener("click", () => handoffInput.click());
handoffInput.addEventListener("change", async () => {
  const [file] = handoffInput.files;
  handoffInput.value = "";
  if (!file) return;
  clearHandoffPreview();
  try {
    if (file.size > handoffMaxBytes) throw new Error("Choose a handoff JSON file up to 64 KiB.");
    const text = new TextDecoder("utf-8", { fatal: true }).decode(await file.arrayBuffer());
    const data = parseHandoff(text);
    showHandoff(data);
    handoff.from = data.from;
    updateDirection("handoff", data.from);
    for (const field of ["title", "request", "context"]) byId(`handoff-${field}`).value = data[field];
  } catch (error) {
    setError("handoff-error", error.message);
  }
});
byId("copy-handoff").addEventListener("click", () => copyFrom(byId("handoff-preview"), "Handoff prompt copied."));
byId("download-handoff").addEventListener("click", () => {
  const output = handoff.output;
  if (output) {
    download(`handoff-to-${output.to}.skillrelay.json`, output.json, "application/json");
    notify("JSON sent to browser downloads.");
  }
});

updateDirection("converter", converter.from);
updateDirection("handoff", handoff.from);
