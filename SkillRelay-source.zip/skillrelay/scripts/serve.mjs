import { readFile } from "node:fs/promises";
import { createServer } from "node:http";
import { join } from "node:path";
import { buildSite } from "./build.mjs";

const port = Number(process.env.SKILLRELAY_PORT ?? 4173);
if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error("SKILLRELAY_PORT must be a valid port.");

const directory = await buildSite();
const files = new Map([
  ["/", ["index.html", "text/html"]],
  ["/index.html", ["index.html", "text/html"]],
  ["/app.js", ["app.js", "text/javascript"]],
  ["/styles.css", ["styles.css", "text/css"]],
  ["/skillrelay.html", ["skillrelay.html", "text/html"]],
  ["/THIRD_PARTY_NOTICES.txt", ["THIRD_PARTY_NOTICES.txt", "text/plain"]],
]);
const server = createServer(async (request, response) => {
  if (!["GET", "HEAD"].includes(request.method)) {
    response.writeHead(405, { Allow: "GET, HEAD" }).end();
    return;
  }
  const entry = files.get(request.url.split("?")[0]);
  if (!entry) {
    response.writeHead(404).end();
    return;
  }
  try {
    const [file, type] = entry;
    const content = await readFile(join(directory, file));
    response.writeHead(200, {
      "Content-Type": type + "; charset=utf-8",
      "Content-Length": content.length,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    }).end(request.method === "HEAD" ? undefined : content);
  } catch {
    response.writeHead(500).end();
  }
});
server.listen(port, "127.0.0.1", () =>
  console.log(`SkillRelay is running at http://127.0.0.1:${server.address().port}`)
);
