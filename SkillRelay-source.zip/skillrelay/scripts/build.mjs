import { build } from "esbuild";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const dist = join(root, "dist");
const require = createRequire(import.meta.url);

export async function buildSite() {
  const { outputFiles } = await build({
    absWorkingDir: root,
    entryPoints: ["web/app.mjs"],
    bundle: true,
    format: "esm",
    platform: "browser",
    target: ["chrome109", "firefox116", "safari16.4"],
    loader: { ".md": "text" },
    legalComments: "inline",
    minify: true,
    write: false,
  });
  const script = outputFiles[0].text;
  const [html, style, license, zipLicense, yamlLicense] = await Promise.all([
    readFile(join(root, "web/index.html"), "utf8"),
    readFile(join(root, "web/styles.css"), "utf8"),
    readFile(join(root, "LICENSE"), "utf8"),
    readFile(join(dirname(require.resolve("@zip.js/zip.js/package.json")), "LICENSE"), "utf8"),
    readFile(join(dirname(require.resolve("yaml/package.json")), "LICENSE"), "utf8"),
  ]);
  const notices = `SkillRelay\n\n${license}\n--- zip.js ---\n\n${zipLicense}\n--- YAML ---\n\n${yamlLicense}`;
  const standalone = html
    .replace("script-src 'self'", "script-src 'unsafe-inline'")
    .replace("style-src 'self'", "style-src 'unsafe-inline'")
    .replace('<link rel="stylesheet" href="styles.css">', () => `<style>\n${style}\n</style>`)
    .replace('<script src="app.js" type="module"></script>', () =>
      `<script type="module">\n${script.replace(/<\/script/giu, "<\\/script")}\n</script>`
    )
    .replace("</body>", () => `<!--\n${notices.replaceAll("-->", "-- >")}\n-->\n</body>`);
  await mkdir(dist, { recursive: true });
  await Promise.all([
    writeFile(join(dist, "index.html"), html),
    writeFile(join(dist, "app.js"), script),
    writeFile(join(dist, "styles.css"), style),
    writeFile(join(dist, "skillrelay.html"), standalone),
    writeFile(join(dist, "THIRD_PARTY_NOTICES.txt"), notices),
  ]);
  return dist;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await buildSite();
  console.log("Built dist/index.html and the standalone dist/skillrelay.html.");
}
