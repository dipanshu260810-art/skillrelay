# SkillRelay

SkillRelay repackages Agent Skills for Claude or ChatGPT. It keeps reusable instructions and supporting files together and reports the parts that need manual work. It also creates handoffs so one assistant can pick up a draft or decision from another.

## Try the converter

Use Node.js 22 or newer to build from this repository.

```sh
npm ci
npm run build
```

Open `dist/skillrelay.html` in your browser. This single file works offline and can be shared by itself. Use `npm start` if you prefer a local preview at `http://127.0.0.1:4173`. To host the web app, serve the generated `dist/` directory as static files.

1. Choose a direction, then add one skill ZIP or a standalone `SKILL.md`. **Try sample** loads a meeting summary skill with a bundled template.
2. Convert and read the compatibility report. Check any cited tools, scripts, and removed settings against the destination.
3. Download the ZIP. Every package has one top-level folder named after the skill, with `SKILL.md` and its supporting files inside. Use **Copy instructions** to reuse the Markdown in a regular chat and attach any reviewed references separately.

## Where to use the output

| Destination | What to do |
| --- | --- |
| ChatGPT | If your workspace supports uploads, go to **Plugins → Skills → Add → Upload from your computer**. Otherwise, paste the instructions into a chat. [OpenAI’s Skills guide](https://help.openai.com/en/articles/20001066-skills-in-chatgpt) |
| Codex | Unzip the skill folder into `.agents/skills/` for your project. [OpenAI’s Codex skill locations](https://learn.chatgpt.com/docs/build-skills#where-codex-loads-local-skills) |
| Claude | On an eligible account with file creation enabled, use **Customize → Skills** to upload the ZIP. [Anthropic’s Skills guide](https://support.claude.com/en/articles/12512180-use-skills-in-claude) |
| Claude Code | Unzip the skill folder into `.claude/skills/` for your project. [Anthropic’s skill locations](https://code.claude.com/docs/en/skills#choose-where-skills-load) |

Native ChatGPT Skills depend on account and workspace settings. Claude consumer access is for people 18 and older. Anyone can use SkillRelay itself offline without signing into either assistant. [OpenAI account availability](https://help.openai.com/en/articles/20001066-skills-in-chatgpt), [Anthropic minimum age](https://support.claude.com/en/articles/8114491-get-started-with-claude)

## Pass work between assistants

In **Chat handoff**, pick a direction, add a task and the context you want to share, and preview the result. Copy it into the receiving chat, or download the JSON to reopen it later. Share the resulting reply back by reversing the direction and adding the excerpt you choose.

Two local MCP clients can also exchange handoffs through a shared folder. SkillRelay provides `send_handoff` and `read_handoff`. Users keep their own sign-ins with each provider and select what to share. See [local MCP setup](docs/handoff.md).

## Command line

Start with the example Markdown or pass a ZIP if the skill has supporting files.

```sh
node bin/skillrelay.mjs convert examples/meeting-brief/SKILL.md --to chatgpt
node bin/skillrelay.mjs convert meeting-brief-for-chatgpt.zip --to claude
npm test
```

Use `--out <file.zip>` to choose a destination. The command reports adaptations and review items in the terminal. Existing output files are protected from accidental overwrites.

## What the converter changes

- Normalizes the skill name and folder, validates the shared frontmatter, and keeps the Markdown instructions and supporting file contents. Export to Claude also normalizes reserved provider words in the name.
- Removes host-specific headers and configuration such as Claude Code hooks, preapproved tools, and `agents/openai.yaml`. It flags some common tool names, Claude Code substitutions, missing linked files, and bundled scripts. Plan to recreate needed settings on the destination and test the skill there. Dropped settings cannot be recovered by converting back.
- Accepts up to 256 ZIP entries, 24 MiB compressed, and 20 MiB unpacked, with a 10 MiB per-entry limit. `SKILL.md` is limited to 512 KiB. Password-protected ZIPs, ambiguous paths, links and special files are rejected.

The converter runs locally and treats skill files as data. It does not run scripts or open links from a skill. The compatibility report is a format check plus a few migration checks. Inspect what the skill tells an assistant to do before enabling it. Convert and redistribute skills you have permission to use.

## Contributing

Start with the existing tests. For a bug report, include the direction, expected result, and a small example that you can share. Please use synthetic examples in issues and tests. See the [Agent Skills specification](https://agentskills.io/specification) for the common format.

The initial implementation was built with AI assistance. Code and the example are available under the [MIT license](LICENSE).
