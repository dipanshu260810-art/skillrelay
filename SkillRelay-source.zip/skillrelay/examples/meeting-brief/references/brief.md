# Meeting brief template

## Decisions

- State each decision in one sentence.

## Actions

- Write the task, owner, and due date, if present.

## Open questions

- List decisions that still need an answer.
