---
name: meeting-brief
description: Turn meeting notes into a short update with decisions, action items, and open questions. Use when someone asks for a meeting summary or a handoff.
license: MIT
disable-model-invocation: true
argument-hint: [meeting notes]
---

# Write a meeting brief

1. Read the notes provided by the user.
2. Use the sections in [the brief template](references/brief.md).
3. Keep decisions separate from proposals. Use "Unassigned" if the notes give no action owner.
4. Preserve unresolved questions and any dates written in the notes.
5. Ask the user to review the draft before sharing it.
